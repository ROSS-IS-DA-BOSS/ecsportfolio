//Ross Pohlsander | Shape Game \ March 9 2026
PImage img;
PImage img2;
PImage img3;
int x, tx, ty, tz, score;
int speed = 4;
float ghostSpeed = 3.0; 
float y;
float ghostX = -50, ghost2X = -250, ghost3X = -450;
boolean moveUp, moveDown, moveLeft, moveRight;

void setup() {
  size(500, 500);
  img = loadImage("BoulderV2.png");
  img2 = loadImage("Space.png");
  img3 = loadImage("Space2.jpeg");
  x = width/2;
  y = height * 0.8;
  tx = int(random(30, width-30));
  ty = int(random(30, width-30));
  tz = int(random(30, width-30));
}

void draw() {
  background(255);
  image(img3, 0, 0, width*2, height*2);
  ghostX += ghostSpeed;  
  ghost2X += ghostSpeed;
  ghost3X += ghostSpeed;

  if (ghostX > 550) {
    ghostX = -50; 
    score++;
    ghostSpeed += 0.1;
    tx = int(random(30, width-30));
  }
  if (ghost2X > 550) {
    ghost2X = -50; 
    ty = int(random(30, width-30));
  }
  if (ghost3X > 550) {
    ghost3X = -50; 
    tz = int(random(30, width-30));
  }

  if (moveUp)    y -= speed;
  if (moveDown)  y += speed;
  if (moveLeft)  x -= speed;
  if (moveRight) x += speed;

  if(x < 50) x = 51;
  if(x > width-50) x = width-51;
  if(y < -25) y = height + 24;
  if(y > height + 25) y = -24;

  fill(0, 150, 255);
  rectMode(CENTER);

  image(img2, x, y, 100, 100);
  target();
  scorePanel();
}

void target() {
  float d1 = dist(x, y, tx, ghostX);
  float d2 = dist(x, y, ty, ghost2X);
  float d3 = dist(x, y, tz, ghost3X);
  
  if (img != null) {
    imageMode(CENTER);
    image(img, tx, ghostX, 50, 50);
    image(img, ty, ghost2X, 50, 50);
    image(img, tz, ghost3X, 50, 50);
  } else {
    fill(200, 0, 0);
    ellipse(tx, ghostX, 50, 50);
    ellipse(ty, ghost2X, 50, 50);
    ellipse(tz, ghost3X, 50, 50);
  }

  if (d1 < 75 || d2 < 75 || d3 < 75) {
    gameOver();
  }
}

void gameOver() {
  background(0);
  fill(255, 0, 0);
  textSize(40);
  textAlign(CENTER, CENTER);
  text("GAME OVER", width/2, height/2);
  fill(255);
  textSize(20);
  text("Score: " + score, width/2, height/2 + 50);
  noLoop();
}

void scorePanel() {
  rectMode(CORNER);
  fill(127, 150);
  noStroke();
  rect(0, 0, width, 30);
  fill(255);
  textAlign(LEFT, CENTER);
  textSize(16);
  text("Score: " + score, 20, 15);
}

void keyPressed() {
  if (key == 'w' || key == 'W') moveUp = false;
  if (key == 's' || key == 'S') moveDown = false;
  if (key == 'a' || key == 'A') moveLeft = true;
  if (key == 'd' || key == 'D') moveRight = true;
}

void keyReleased() {
  if (key == 'w' || key == 'W') moveUp = false;
  if (key == 's' || key == 'S') moveDown = false;
  if (key == 'a' || key == 'A') moveLeft = false;
  if (key == 'd' || key == 'D') moveRight = false;
}

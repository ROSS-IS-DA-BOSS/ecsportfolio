//Ross Pohlsander |Feb 23 2026 | Timeline
PImage mozart;
import ddf.minim.*;
import ddf.minim.signals.*;
import ddf.minim.ugens.*;


Minim minim;
AudioOutput out;

String[] dates = {
  "January 27th 1756",
  "December 1761",
  "1763–1766",
  "October 1769",
  "1769–1773",
  "March 1781",
  "August 4th 1782",
  "December 5, 1791",

};
String[] details ={
  "Mozart is born in Salzburg, Austria.",
  "He writes his first piece.",
  "Mozart toured Europe and performed in London and Paris.",
  "Mozart was appointed as Konzertmeister for the Archbishop of Salzburg.",
  "He made three trips to Italy to study opera",
  "He moved to Vienna.",
  "Married Constanze Weber.",
  "Died at age 35 in Vienna",
};
void setup() {
  
  background(#ffffff);
  size(950, 400);
  fill(#000000);
  minim = new Minim(this);
  out = minim.getLineOut();
  out.setGain(10.0);
  out.unmute();
  mozart = loadImage("Mozart.png");
  mozart.resize(100, 100);
  
}
void draw() {
  background(#ddddff);
  strokeWeight(5);
  fill(#000000);
  line(75, 200, 950-75, 200);
  strokeWeight(1);
  textAlign(CENTER);
  textSize(34);
  fill(#000000);
  text("Mozart Life", 475, 150);
  textSize(10);
  text("By Ross Pohlsander", 475, 170);




  drawRef(0, 0, 100, 220);
  drawRef(1, 1, 200, 240);

  drawRef(3, 3, 400, 280);
  drawRef(2, 2, 300, 260);
  drawRef(4, 4, 500, 220);
  drawRef(5, 5, 600, 240);
  drawRef(6, 6, 700, 220);
  drawRef(7, 7, 800, 240);
  march(350, 60);
  marchNotes(75, 50, 20);
  fill(#000000);
  fill(#000000);
  line(75, 200, 950-75, 200);
}
void drawRef(int t, int d, float x, float y) {
  strokeWeight(2);
  fill(#000000);
  line(x, 200, x, y);

  float w = textWidth(details[t]) + 4;
  float h = 15;


  float rectX = x - (w / 2);
  float rectY = y - 1;


  if (mouseX > rectX && mouseX < rectX + w &&
    mouseY > rectY && mouseY < rectY + h) {

    fill(#FFaa77);
    image(mozart, 0, 0);
    image(mozart, 850, 0);
  } else {
    fill(#aa77FF);
  }



  rect(rectX, rectY, w, h, 5);

  textAlign(CENTER);
  fill(0);
  text(details[t], x, y + 10);
  noStroke();

  text(dates[d], x, 185);
  stroke(0);
  strokeWeight(2);
  line(x, 190, x, 210);
}

void mousePressed() {
  float dShort = 0.4;  
  float dLong = 1.2;  
  
  playBoldNote(0.0, dShort, 196.00); 
  playBoldNote(0.4, dShort, 196.00); 
  playBoldNote(0.8, dShort, 196.00); 
  playBoldNote(1.2, dLong, 155.56); 

  playBoldNote(3.0, dShort, 174.61); 
  playBoldNote(3.4, dShort, 174.61); 
  playBoldNote(3.8, dShort, 174.61); 
  playBoldNote(4.2, dLong, 146.83);;
}
void playBoldNote(float start, float dur, float freq) {
  out.playNote(start, dur, freq);
  out.playNote(start, dur, freq / 2); 
}

void arrow(int x, int y) {
  quad(x-10, y+30, x, y, x-10, y-30, x+20, y);
}
void march(int yLevel, int spacing) {

  int range = 1030;

  for (int i = 0; i < 17; i++) {

    float xPos = ((i * spacing + frameCount) % range) - 30;
    arrow((int)xPos, yLevel);
  }
}
void marchNotes(int yLevel, int spacing, int numNotes) {
  int range = 1030;

  for (int i = 0; i < numNotes; i++) {

    float xPos = ((i * spacing + frameCount * 2) % range) - 30;


    float h = noise(i) * 100 - 50;
    float yPos = yLevel + h;

    notes((int)xPos, (int)yPos, 392.00);
    fill(#000000);
  }
}

void notes(int x, int y, float freq) {

  boolean isHovering = mouseX > x - 10 && mouseX < x + 10 && 
                       mouseY > y - 10 && mouseY < y + 10;

  if (isHovering) {
    fill(#ff0000);
    stroke(255, 0, 0);
    
 
    
  } else {
    fill(0);
    stroke(0);
  }
  

  noStroke();
  ellipse(x, y, 10, 10);


  strokeWeight(1);
  stroke(isHovering ? #ff0000 : 0); 
  line(x + 5, y, x + 5, y - 20);
   fill(#000000);
}

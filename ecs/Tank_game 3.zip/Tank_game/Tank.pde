class Tank {
  float x, y;
  float bodyAngle = 0; 
  float turretAngle = 0; 

  Tank(float x, float y) {
    this.x = x;
    this.y = y;
  } 

  void display() {
    turretAngle = atan2(mouseY - y, mouseX - x);
    pushMatrix();
    translate(x, y); 
    pushMatrix();

    fill(100, 200, 100);
    rect(-25, 20, 80, 60); 
    fill(0);
    ellipse(-25, 40, 100, 30); 
    fill(60);
    ellipse(-25, 40, 90, 27); 
    popMatrix();
    pushMatrix();
    rotate(turretAngle); 
    fill(50, 150, 50);
    rect(-50, 0, 100, 15);
    ellipse(0, 0, 40, 40); 
    popMatrix();
    popMatrix();
  } 

  void move() {
    if (moveLeft)  x -= speed;
    if (moveRight) x += speed;
    
  } 

}

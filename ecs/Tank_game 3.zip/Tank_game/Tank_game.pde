//tank game | Ross Pohlsander | Apr 1
Tank aTank;
boolean moveUp = false;
boolean moveDown = false;
boolean moveLeft = false;
boolean moveRight = false;
float speed = 5;
float angle = 0;
float x = 200;  

void setup() {
  aTank = new Tank(300, 300);
  size(400, 400);
  rectMode(CENTER);
}
void draw() {
  background(240);
  aTank.move(); 
  aTank.display();
  

}

void keyPressed() {
  if (key == 'w' || key == 'W') moveUp = true;
  if (key == 's' || key == 'S') moveDown = true;
  if (key == 'a' || key == 'A') moveLeft = true;
  if (key == 'd' || key == 'D') moveRight = true;
}


void keyReleased() {
  if (key == 'w' || key == 'W') moveUp = false;
  if (key == 's' || key == 'S') moveDown = false;
  if (key == 'a' || key == 'A') moveLeft = false;
  if (key == 'd' || key == 'D') moveRight = false;
}

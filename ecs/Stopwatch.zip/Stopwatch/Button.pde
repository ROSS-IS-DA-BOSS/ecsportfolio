class Button {
  int x; int y; int size; int size2; String text;
  
  Button(int x, int y, int size, int size2, String text){
    this.x=x; this.y=y; this.size=size; this.size2=size2; this.text=text;
  }
  
  void display(){
    fill(#ff7766);
    if(mouseX > x-(size/2) && mouseX < x+(size/2) && mouseY > y-(size2/2) && mouseY < y+(size2/2)){
      fill(#77ff66);
      if (mousePressed) {
        if(text.equals("Stop")){
          mode= 1;
          if (alarm != null && alarm.isPlaying()) alarm.pause();
        }
        if(text.equals("Start")) mode=2;
        if(text.equals("Reset")){
          time=0; mode=1; a=0;
          if(alarm != null) { alarm.pause(); alarm.rewind(); }
        }
        if(text.equals("Count down")) mode=3;
        if(text.equals("-10")){ time -= 10; mousePressed = false; }
        if(text.equals("+10")){ time += 10; mousePressed = false; }
      } 
    }
    rect(x,y,size, size2, 50);
    fill(0);
    textSize(17);
    textAlign(CENTER, CENTER);
    text(text,x,y);
  }
}

//Stop watch | ROSS POHLSANDER | March 25
import ddf.minim.*;

Minim minim;
AudioPlayer alarm;
boolean isAlarmPlaying = false; 
boolean triggerAlarm = false;
Button b1, b2, b3, b4, b5, b6;
float  time;
int mode;
float q=0;
float a=0;

void setup(){
  time = 0;
  mode = 1;
  size(500,500);
  minim = new Minim(this);
  alarm = minim.loadFile("alarm1.wav");
  rectMode(CENTER);
  b1 = new Button(width/2,height/2,100,50,"Start");  
  b2 = new Button(width/4,height/2,100,50,"Reset");  
  b3 = new Button(width/4+(width/2),height/2,100,50,"Count down");
  b4 = new Button((int(width*0.37)), (int(height*0.62)),50,50,"-10");
  b5 = new Button((int(width*0.63)), (int(height*0.62)),50,50,"+10");
  b6 = new Button(width/2, (int(height*0.62)),50,50,"Stop");
  
  thread("Timer");
}

void draw(){
  synchronized(this) {
    ground();
    ground();
    b1.display(); b2.display(); b3.display();
    b4.display(); b5.display(); b6.display();
    
    textSize(60);
    fill(0);
    text(nf(time, 0, 2), width / 2, 100);

    if (triggerAlarm) {
      if (alarm != null) {
        alarm.rewind();
        alarm.play();
      }
      triggerAlarm = false; 
    }
  }
}

void time(){
  synchronized(this) {
    if (mode == 2) { 
      time += 0.01;
    } else if (mode == 3) { 
      time -= 0.01;
    }
    
    if (time < 0) {
      time = 0;
    }

    if (q != 0){
      time = time + (q * 10);
      q = 0;
    }

    if (a == 1 && time <= 0 && mode == 3) {
      triggerAlarm = true;  
      a = 0;
      mode = 1;
    }

    if (time > 0){
      a = 1;
    }
  }
}

void ground(){
  background(#99ddff);
  rectMode(CORNER);
  fill(#009900);
  rect(0,height/2,width+10,height+10);
  rectMode(CENTER);
  fill(#ffff00);
  ellipse(0,0,150,150);
}

void Timer() {
  while(true) {
    time();
    try { Thread.sleep(10); } catch (Exception e) {}
  }
}

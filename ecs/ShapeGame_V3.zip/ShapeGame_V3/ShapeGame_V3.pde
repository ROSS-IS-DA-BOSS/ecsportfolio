//Ross Pohlsander | Shape Game | March 9 2026
PImage img, img2, img3;
int x, tx, ty, tz, score;
int speed = 4;
float px, py; 
float ghostSpeed = 3.0;
float y;
float bgY = 0; 
float ghostX = -50, ghost2X = -250, ghost3X = -450;
boolean moveUp, moveDown, moveLeft, moveRight;
boolean shooting = false; 
int lastFrame = 0; 
int coolDownFrames = 20;
void setup() {
  size(500, 500);
  img = loadImage("BoulderV2.png");
  img2 = loadImage("Space.png");
  img3 = loadImage("Space2.jpeg");
  x = width/2;
  y = height * 0.8;
  tx = int(random(30, width-30));
  ty = int(random(30, width-30));
  tz = int(random(30, width-30));
}
void draw() {
  background(0);
  if (img3 != null) {
    imageMode(CORNER);
    image(img3, 0, bgY, width, height);
    image(img3, 0, bgY - height, width, height);
    bgY += 2; // Scroll speed
    if (bgY >= height) bgY = 0;
  }
  if (shooting) {
    py -= 10; 
    fill(#FFCC00); 
    noStroke();
    ellipse(px, py, 10, 20);    
    if (py < 0) {
      shooting = false;
    }
    if (dist(px, py, tx, ghostX) < 40) {
      ghostX = -50; tx = int(random(30, width-30));
      shooting = false; score++;
    }
    if (dist(px, py, ty, ghost2X) < 40) {
      ghost2X = -50; ty = int(random(30, width-30));
      shooting = false; score++;
    }
    if (dist(px, py, tz, ghost3X) < 40) {
      ghost3X = -50; tz = int(random(30, width-30));
      shooting = false; score++;
    }
  }
  ghostX += ghostSpeed;
  ghost2X += ghostSpeed;
  ghost3X += ghostSpeed;
  if (ghostX > 550) { ghostX = -50; tx = int(random(30, width-30)); }
  if (ghost2X > 550) { ghost2X = -50; ty = int(random(30, width-30)); }
  if (ghost3X > 550) { ghost3X = -50; tz = int(random(30, width-30)); }
  if (moveUp)    y -= speed;
  if (moveDown)  y += speed;
  if (moveLeft)  x -= speed;
  if (moveRight) x += speed;
  x = constrain(x, 50, width-50);
  y = constrain(y, 50, height-50);
  imageMode(CENTER);
  if (img2 != null) {
    image(img2, x, y, 100, 100);
  }
  target();
  scorePanel();
}
void target() {
  float d1 = dist(x, y, tx, ghostX);
  float d2 = dist(x, y, ty, ghost2X);
  float d3 = dist(x, y, tz, ghost3X);
  if (img != null) {
    imageMode(CENTER);
    image(img, tx, ghostX, 50, 50);
    image(img, ty, ghost2X, 50, 50);
    image(img, tz, ghost3X, 50, 50);
  }
  if (d1 < 50 || d2 < 50 || d3 < 50) {
    gameOver();
  }
}
void proj() {
  if (frameCount - lastFrame > coolDownFrames) {            
    lastFrame = frameCount; 
    shooting = true;
    px = x; 
    py = y; 
  }
}
void gameOver() {
  background(0);
  fill(255, 0, 0);
  textAlign(CENTER, CENTER);
  textSize(40);
  text("GAME OVER", width/2, height/2);
  textSize(20);
  text("Score: " + score, width/2, height/2 + 50);
  noLoop();
}
void scorePanel() {
  rectMode(CORNER);
  fill(127, 150);
  rect(0, 0, width, 30);
  fill(255);
  textAlign(LEFT, CENTER);
  textSize(16);
  text("Score: " + score, 20, 15);
}
void keyPressed() {
  if (key == 'w' || key == 'W') proj();
  if (key == 's' || key == 'S') moveDown = false;
  if (key == 'a' || key == 'A') moveLeft = true;
  if (key == 'd' || key == 'D') moveRight = true;
  if (key == ' ') proj();
}
void keyReleased() {
  if (key == 'w' || key == 'W') moveUp = false;
  if (key == 's' || key == 'S') moveDown = false;
  if (key == 'a' || key == 'A') moveLeft = false;
  if (key == 'd' || key == 'D') moveRight = false;
}
